# Recovery Manifest

| Final file | Source file | Decision |
|---|---|---|
| src/main.py | ~/swexp-lab/l02/dump/main.py | Kept original; main_COPY.py had matching checksum |
| src/payments.py | ~/swexp-lab/l02/dump/stray/payments.py | Recovered from stray folder |
| config/settings.conf | ~/swexp-lab/l02/dump/settings.conf | Configuration belongs in config/ |
| docs/README.md | ~/swexp-lab/l02/dump/readme.txt | Renamed to conventional README.md |
