def pay():
    return 'paid'
